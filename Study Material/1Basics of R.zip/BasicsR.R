x<-6
x=6
y<-"a"
y="a"
y
1+1
2*9
3-7
# 2^3 = 8; log of 8 to the base 2 is 3 
log(10) # Log of 10 to the base e; 3.302585
exp(1) # antilog of 1; 2.718282
log(10,2) # log of 10 to the base 2; 3.321928
log(10,10) # log of 10 to the base 10 = 1
log10(2) # log of 2 to the base 10; 0.30103
log(20/5) # 1.386294
3-7
abs(3-7) # returns ABSOLUTE 
runif(7) # genertae random numbers between 0 and 1
1.9e3 #1900
1.9e-2 #0.019
200%/%11 # 200/11 = 18.18; answer is 18; how many 11 are included in 200 
200%%11 # 200/11 = 18.18; 200*11 = 198; 200-198=2; ANSWER is 2
# 11s are shared in 200
round((1.234567), digits = 3) # 1.235; 4 is 
# rounded to 5 bcz next number was 5 (=,> 5)
round((1.234467), digits = 3) # 1.235; 4 is 
# taken as 4 bcz next number was 4 (=,< 5)
floor(3.7) # Smallest INTEGER than 3.7 = 3
floor(-3.7) # -4
ceiling(3.7) # Largest INTEGER than 3.7 = 4
ceiling(-3.7) # Largest INTEGER than -3.7 = -3
# create a timeline for understanding - figures
ceiling(3.1) # Largest INTEGER than 3.7 = 4
trunc(3.7) # = 3; like floor in case of + figures
trunc(-3.7) # like ceiling in case of - figures; -3
# ----------------------VECTORS
a<- 1:3
a<- 5:10
a<-c(5,6,7,8,9,10)
a
A<- 1:5
A
B<- c(6,7)
B
A*B # see multiplication is happening alternately by 6 and 7
# 6*1=6; 7*2=14; 6*3=18; 7*4=28; 6*5=30
B*A # SAME AS A*B
x<-c(sample(60:100, 20), 15, 23, 150, 168)
x
max(x) # 168
min(x) # 15
sum(x) # 2054
mean(x) # 85.58333
round(mean(x), digits = 2) # 85.58
median(x) # 83
range(x) # 15 & 168
sd(x) # 31.04823
round(sd(x), digits = 2) # 31.05
var(x) # sd*sd = 963.9928; 
31.05*31.05 # 964.1025
length(x) # 24
y<-c(sample(20:60, 20), 15, 23, 150, 168)
y
length(y) #24
cor(x,y) # 0.8296563
round(cor(x,y), digits = 2) # 0.83
x<- c(100,50,75,150,200,25)
x
sort(x) # arranged in low to high, 15, 23,...150, 168
rank(x) # lowest is 25, hence 1, highest is 200, hence 6
order(x) # order is DONE ON sorted numbers....25 was first in sort
# but, it was positioned in the original data at 6th position, hence 6
# next is 50 in sorting which was located at 2 position in the data
# hence 2; next is 75 in sorting, located at 3 in original data, hence, 3
# next is 100, located at 1 in data, hence, 1, next is 150 in sorted data,
# located at 4 in data, hence 4; last was 200 in sorting which was located
# at 5 position, hence 5
x
a<- c(1:5, NA)
a
mean(a) # answer NA
mean(a, na.rm = T) # ANSWER IS 3
a<- c(1:5, NA, NA, 8:10)
a # 1 2 3 4 5 NA NA 8 9 10
is.na(a) #FALSE FALSE FALSE FALSE FALSE  TRUE  TRUE FALSE FALSE FALSE
!is.na(a) # TRUE  TRUE  TRUE  TRUE  TRUE FALSE FALSE  TRUE  TRUE  TRUE
which(is.na(a)) # location no 6th and 7th are NA
# ----Covert NA into 0-------
ifelse(is.na(a),0,a)
ifelse(is.na(a),3,a) # replace by mean as 3
ifelse(is.na(a),"Vinod",a)
ifelse(is.na(a),'Vinod',a)
seq(1:10)
seq(20,10) # comma is important
seq(10,20)
length(seq(10,20)) # 11
seq(5,0, -0.5)
# ---------Repeat---------
x<- rep(6,4)
x # 6 6 6 6
y<- rep(c(11,12,13),3)
y # 11 12 13 11 12 13 11 12 13
z<- rep(c(11,12,13),each = 3)
z # 11 11 11 12 12 12 13 13 13 
# ----------Sub setting -------
x<- c(6, 1:2, 3, NA,12)
x
x[x>5] # 6 NA 12
subset(x, x>5) # 6 12 
#--------Select------
z<- c(6,5,-3,7)
which(z*z>9) # 1 2 4; 6*6=36, 5*5=25, 7*7=49
z*z>9 #TRUE  TRUE FALSE  TRUE
# to know the values
B<- z[z*z>9]
B # 6 5 7 
#--------Character Strings----------
a<-"hello"
b<- "55"
b
as.numeric(a)
as.numeric(b) # converting b into numeric
str(b) # Chr "55"
#---joining hello and 55-----------
paste(a, b, sep = "") # "" means no space between
paste(a, b, sep = " ") # " " leaving one space
paste(a, b, sep = "vinod") # vinod in between hello & 55 
paste(a, b, sep = " vinod ") # space before and after vinod
paste(a, b, " vinod ") # hello 55 vinod
# pasting vinod after hello and 55
d<- c(a,b,"vinod")
d
e<- paste(d, "M Learning R") # M Learning R after each hello & 55
e
#-----------Pattern matching---
x<- c("apple", "potato", "grape", "10", "blue.flower")
x
grep("a", x) # 1 2 3 [1=apple, 2=potato, 3 = grape]
# for values 
grep("[[:digit:]]", x, value = TRUE) # return 10
# -----Index a portion of a string----
x<- "apple"
x
substr(x, start = 2, stop = 5) # pple
substr(x, start = 2, stop = 5)<- "Mgud" # you can have only 4 places
x # aMgud
#--------change first a in apple by A
x<- "apple"
chartr(old = "a", new = "A", x) # Apple; x will still give apple
y<-chartr(old = "a", new = "A", x) 
y # y will be Apple
#-----------use of strsplit-----------
x<- "apple|lime|orange"
x
v=strsplit(x, split = "|", fixed = TRUE)
v
#---------MATRICES------------
# MATRICES are vectors; can be regarded as 2 dimensional arrays
y<- matrix(c(1,2,3,4), nrow = 2, ncol = 2)
y # first, column will be filled 
M<- matrix(c(1,1,1,5,2,7,1,0,3), nrow = 3)
print(M)
class(M) # "matrix"
attributes(M) # $dim  3 3
#-------for transposing the matrix--------
Minv=t(M)
print(Minv)
Minv
k<- matrix(c(50,70,40,90,60,80,50,90,100,50,30,70), nrow = 3)
k # marks of 4 different subjects
#--------Naming the rows and columns------------
rownames(k)<- c("Test1", "Test2", "Test3") 
k
colnames(k)<- c("Maths", "English", "Science", "History")
k
#----------Calculations of rows and columns-------
mean(k[3,]) # 72.5; mean of 3rd row
(40+80+100+70)/4
sd(k[3,]) # sqrt[sum of squares of differences from mean/(n-1)]
sqrt(((40-72.5)^2+(80-72.5)^2+(100-72.5)^2+(70-72.5)^2)/3)
rowSums(k) # 240  250 290
colSums(k) # 160 230 240 150
rowMeans(k) # 60 62.5 72.5
colMeans(k) # 53.33  76.66  80  50
#-------Adding Row and Column---apply function--------
k<- rbind(k, apply(k,2,mean)) # 2 stands for col,mean = mean of columns 
k # a new row at the bottom having means of columns will appear
k<- cbind(k, apply(k,1, var)) # 1 stands for row, var = variance of rows
k
colnames(k)<- c(1:4, "variance") # after 1 to 4 colmns, new col name = variance
rownames(k)<- c(1:3, "mean") # after 1 to 3 rows, 4th row name = mean
k
#---apply function works for rows and columns of a matrix and data frame
T<-k[,-5] # DELETE 5TH COLUMN and store new matrix in T
T
k
L<-k[-4,-5]# deleting 4th row and 5th column
L
a<- apply(L, 1, sum)
a # sum of rows 240 250 290
b<- apply(L, 2, sum)
b # sum of columns 160 230 240 150
apply(L, 1, min) # minimum of rows 50 30 40
apply(L, 1, sqrt) # 1, first row's numbers are sqrt, shown in 1st col
apply(L, 2, sqrt) # 2, first row's nos are sqrt, shown in 1st row
#---------apply your own function----------
apply(L, 1, function(x) x^2+x) #applied on 1st row, shown in 1st col
apply(L, 2, function(x) x^2+x) #applied on 1st row, shown in 1st row
#-------ARRAYS.....(matrix is a special form of ARRAY)----
#-------ARRAY can be of more than 2 dimensions, but,
#Matrix will always be of 2 (row*col) dimension-----
x<- 1:18
x
is.matrix(x) # FALSE bcz x is a vector
is.vector(x) # TRUE bcz x is a vector
is.array(x) # FALSE bcz dimension is not assigned, yet
dim(x)<- c(6,3) # present 1 to 18 nos in 6 rows and 3 columns
dim(x) # 6 3
x
is.matrix(x) # TRUE bcz now it has dimensions 6,3
# Matrix is a special case of ARRAY
is.array(x) # TRUE bcz now it has dimensions 6,3
dim(x) <- c(3,3,2)
x # now there will be two matrices 
# expressed as , , 1 & , , 2
#------ARRAY with letters------
A<- letters[1:18]
A
dim(A)<- c(3,2,3)
A # ,,1: a,b,c,d,e,f; ,,2: g,h,i,j,k,l; ,,3: m,n,o,p,q,r
# Accessing 1st and 2nd table
A[,,1:2]
# If you want to have only m,n,o,p,q,r; which are in 3rd table
A[,,3]
A
A[3,,] # 3rd rows of all 3 tables....c,f; i,l; o,r presented in 3 colmns
# in one table
A[3,,,drop = T] # same like A[3,,]
A[3,,,drop = F] # same like A[3,,] # Now, c,f will be 1st table
# i, l will be 2nd table and o, r will be 3rd table
#----------------LIST--------
# List is a CONTAINER, that's it----
x<-list(u=2, v = "You")
x # $u 2; $v = "You"
x$u # 2
x$v # You
z<- list(a= "My R", b = "Training", c=100)
z
#--------Adding in list----
z$d<- "is super"
z
#----Deleting from list-----
z$c<- NULL
z
#-------lapply function---------
k<- list(1:5, 20:22) # k object is a list having 2 items
k
lapply(k, median) # 3 and 21 in vertical form as an output of list
#------sapply function-----
sapply(k, median) # 3 and 21 in horizontal form
k
#----------Recursive list--------list inside a list----
p<- c(list(a=1, b=2, c=list(d=5, e=9)))
p # $c will have $c$d as 5 and $c$e as 9 other than $a & $b
q<- c(list(a=1, b=2, c=list(d=5, e=9)), recursive = T)
q
#-------------Data Frames--------
kids<-c("John", "Joe", "Julei")
age<-c(12, 10, 8)
d<- data.frame(kids, age, stringsAsFactors = FALSE)
d
#----Access 1st Column---------
d[[1]] # John Joe Julei
d$kids
d[,1]
str(d)
names(d) # names of variable
class(d) # data.frame
head(d,2)
tail(d,2)
d[2:3,] # 2nd to 3rd rows; see comma
d[2:3,2] # 2nd to 3rd rows; see comma and only 2nd column; 10 8
class(d[2:3,2]) # numeric
d[d$age>=10,] # rows those >= 10
#-------Add new row--------
rbind(d,list("Laura", 19)) # new table with Laura 19
#-------Factors-------------
x<-c(1:3)
x
str(x) # integer
y<- factor(x)
y
z<- as.factor(x)
z
str(y)
str(z)
#-------tapply function------
ages<- c(25,26,55,37,21,42)
location<- c("Rural","Urban","Urban","Rural","Urban","Rural")
tapply(ages, location, mean)
# Rural as 34.66667; Urban as 34
(25+37+42)/3
(26+55+21)/3


machine<- c(rep("A", times =5), rep("B", times = 5), rep("C", times = 10))
machine
diameter<-c(18.1, 2.4, 2.7, 7.5, 11.0, 8.7, 56.8, 4.4, 8.3,5.8, 29.7, 18.7, 16.5, 63.7, 18.9, 107.2, 19.7, 93.4, 21.6, 17.8)
length(diameter)
df<- c(machine, diameter)
df<- as.data.frame(df)
is.data.frame(df) # TRUE

with(df,tapply(diameter,machine,mean)) #HW6
with(df,tapply(diameter,machine,median))
with(df,tapply(diameter,machine,sd))
with(df,tapply(diameter,machine, skew)) # skew not worked

